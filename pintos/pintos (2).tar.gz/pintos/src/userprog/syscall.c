#include "userprog/syscall.h"
#include <stdio.h>
#include <stdlib.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "userprog/process.h"


struct lock file_lock;

struct process_file {
  struct file *file;
  int fd;
  struct list_elem elem;
};

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  lock_init(&file_lock);
}

static void syscall_handler (struct intr_frame *f UNUSED) 
{
  int * callvalue =(int*) f->esp;  //syscall value
  int args[3];

  //##Using the number find out which system call is being used
  // numOfArgs = number of args that system call uses {0,1,2,3}
	
  //copy_in (args, (uint32_t *) f->esp + 1, sizeof (*args) * numOfArgs);
  
  check_pointer(callvalue);
  switch(*callvalue)
  {
	  case SYS_HALT:
	  {
		shutdown_power_off();
		break;
	  }
	  case SYS_EXIT:
	  {
		copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);  
		exit(args[0]);
		break;
	  }
	  case SYS_WAIT:
	  {
		copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);  
		f->eax = process_wait(args[0]);
		break;
	  }
	  case SYS_EXEC:
	  {
		  copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);
		  args[0] = user_to_kernel_ptr((const void *) args[0]);
		  f->eax = exec((const char *) args[0]);
		  break;
	  }
	  case SYS_WRITE:
	  { 
		 copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 3);
		 args[1] = user_to_kernel_ptr((const void *) args[1]);
		 f->eax = write(args[0], (const void *) args[1], (unsigned) args[2]);
		 break;
	  }
	  case SYS_READ:
	  {
		  copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 3);
		  args[1] = user_to_kernel_ptr((const void *) args[1]);
		  f->eax = read(args[0], (void *) args[1], (unsigned) args[2]);
		  break;
	  }
	  case SYS_CREATE:
	  {
		 copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 2);
		 args[0] = user_to_kernel_ptr((const void *) args[0]);
		 f->eax = create((const char *) args[0], (unsigned) args[1]);
		 break; 
	  }
	  case SYS_REMOVE:
	  {
		 copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);
		 args[0] = user_to_kernel_ptr((const void *) args[0]);
		 f->eax = remove((const char *) args[0]);
		 break;
	  }
	  case SYS_OPEN:
	  {
		 copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);
		 args[0] = user_to_kernel_ptr((const void *) args[0]);
		 f->eax = open((const char *) args[0]);
		 break;
	  }
	  case SYS_CLOSE:
	  {
		  copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);
		  close(args[0]);
		  break;
	  }
	  case SYS_FILESIZE:
	  {
		  copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);
		  f->eax = filesize(args[0]);
		  break;
	  }
	  case SYS_SEEK:
	  {
		  copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 2);
		  seek(args[0], (unsigned) args[1]);
		  break;
	  }
	  case SYS_TELL:
	  {
		  copy_in(args, (uint32_t *) f->esp + 1, sizeof *args * 1);
		  f->eax = tell(args[0]);
		  break;
	  }
	  default:
	  {
		exit(-1);
		break;
	  }
  }
};

/*checks if the current thread has a live parent, and changes own status
if so. After, prints details then exits */
void exit (int status)		
{		
  struct thread *cur = thread_current();		
  if (thread_alive(cur->parent))		
    {		
      cur->cp->status = status;		
    }		
  printf ("%s: exit(%d)\n", cur->name, status);		
  thread_exit();		
}

tid_t exec ( const char * cmd_line)
{
  tid_t pid = process_execute(cmd_line);
  struct child_process* cp = get_child(pid);
  ASSERT(cp);
  while (cp->load == 0)
    {
      barrier();
    }
  if (cp->load == -1)
    {
      return -1;
    }
  return pid;
}

int write (int fd, const void *buffer, unsigned size)
{
  if (fd == STDOUT_FILENO)
    {
      putbuf(buffer, size);
      return size;
    }
  lock_acquire(&file_lock);
  struct file *f = process_get_file(fd);
  if (!f)
    {
      lock_release(&file_lock);
      return -1;
    }
  int bytes = file_write(f, buffer, size);
  lock_release(&file_lock);
  return bytes;
}

int read(int fd, void *buf, unsigned size)
{
	unsigned i, bytes;
	uint8_t * buffer;
	struct file *f;
	
	if(fd == STDIN_FILENO)
	{
		buffer = (uint8_t *) buf;
		for(i = 0; i < size; i++);
			buffer [i] = input_getc();
	}
	
	lock_acquire(&file_lock);
	f = process_get_file(fd);
	if (!f)
    {
      lock_release(&file_lock);
      return -1;
    }
	bytes = file_read(f,buf,size);
	lock_release(&file_lock);
	return bytes;
	
	
}

bool create(const char * file_name, unsigned size)
{
	bool ret;
	lock_acquire(&file_lock);
	ret = filesys_create(file_name, size);
	lock_release(&file_lock);
	return ret;
}

bool remove(const char * file_name)
{
	bool ret;
	lock_acquire(&file_lock);
	ret = filesys_remove(file_name);
	lock_release(&file_lock);
	return ret;
}

int open(const char * file_name)
{
	int fd;
	lock_acquire(&file_lock);
	
	struct file * file = filesys_open(file_name);
	
	if(!file)
	{
		lock_release(&file_lock);
	    return -1;
	}
	fd = process_add_fd(file);
	
	lock_release(&file_lock);
	return fd;
}

void close(int fd)
{
    lock_acquire(&file_lock);
	process_close_fd(fd);
	lock_release(&file_lock);
}

int filesize( int fd )
{
	lock_acquire(&file_lock);
	struct file *f = process_get_file(fd);
	if (!f)
	{
		lock_release(&file_lock);
		return -1;
	}
	int size = file_length(f);
	lock_release(&file_lock);
	return size;
}

void seek(int fd, unsigned position)
{
	lock_acquire(&file_lock);
	struct file *f = process_get_file(fd);
	if (!f)
	{
		lock_release(&file_lock);
		return;
	}
	file_seek(f, position);
	lock_release(&file_lock);
}

unsigned tell(int fd)
{
	off_t ofs;
	lock_acquire(&file_lock);
	struct file *f = process_get_file(fd);
	if (!f)
	{
		lock_release(&file_lock);
		return -1;
	}
	ofs = file_tell(f);
	lock_release(&file_lock);
	return ofs;
}


/* checks if pointer is not a user vaddr by vaddr.h and is greater than
 * or equal to the Bottom of user data in syscall.h*/
void check_pointer (const void *pointer)		
{		
  if (!is_user_vaddr(pointer) || pointer < USER_DATA_BOTTOM )		
    {		
      exit(-1);		
    }		
}

/* Copies SIZE bytes from user address USRC to kernel address
   DST.
   Call thread_exit() if any of the user accesses are invalid. */
void
copy_in (void *dst_, const void *usrc_, size_t size) 
{
  uint8_t *dst = dst_;
  const uint8_t *usrc = usrc_;
 
  for (; size > 0; size--, dst++, usrc++) 
  {
    if (usrc >= (uint8_t *) PHYS_BASE || !get_user (dst, usrc)) 
      exit(-1);
    check_pointer(usrc);  
  }
};

/* Copies a byte from user address USRC to kernel address DST.
   USRC must be below PHYS_BASE.
   Returns true if successful, false if a segfault occurred. */
inline bool
get_user (uint8_t *dst, const uint8_t *usrc)
{
  int eax;
  asm ("movl $1f, %%eax; movb %2, %%al; movb %%al, %0; 1:"
       : "=m" (*dst), "=&a" (eax) : "m" (*usrc));
  return eax != 0;
};

struct file* process_get_file (int fd)
{
  struct thread *t = thread_current();
  struct list_elem *e;

  for (e = list_begin (&t->files); e != list_end (&t->files);
       e = list_next (e))
        {
          struct process_file *pf = list_entry (e, struct process_file, elem);
          if (fd == pf->fd)
				return pf->file;
  }
  return NULL;
}

int process_add_fd(struct file * file)
{
	struct process_file * proc_file = malloc(sizeof(struct process_file));
	
	proc_file->file = file;
	proc_file->fd = thread_current()->fd;
	thread_current()->fd++;
	list_push_front(&thread_current()->files, &proc_file->elem);
	return proc_file->fd;
	
}

void process_close_fd(int fd)
{
	struct thread * t;
	struct list_elem *next, *felem;
	struct process_file * proc_file;
	
	t = thread_current();
	felem = list_begin(&t->files);
	
	while(felem != list_end(&t->files))
	{
		next = list_next(felem);
		proc_file = list_entry(felem, struct process_file, elem);
		
		if(fd == -1 || proc_file->fd == fd)
		{
			file_close(proc_file->file);
			list_remove(&proc_file->elem);
			free(proc_file);
			
			if(fd != -1)
				return;
			
		}
		felem = next;
	}
	
}


/*get's child process struct by looping through the current thread's 
 and returns the cp in which the child proccesses match. 
 returns Null if no match found */
struct child_process* get_child (int pid)
{
  struct thread *t = thread_current();
  struct list_elem *e;

  for (e = list_begin (&t->children); e != list_end (&t->children); e = list_next (e))
  {
       struct child_process *cp = list_entry (e, struct child_process, elem);
       if (pid == cp->pid)
	      return cp;
   }
  return NULL;
}

//removes child elem from list, then free's cp space.
void remove_child (struct child_process *cp)
{
  list_remove(&cp->elem);
  free(cp);
}

void remove_children()
{
  struct thread *t = thread_current();
  struct list_elem *e, *next;
  struct child_process * cp;

  e = list_begin(&t->children);
  
  while(e != list_end(&t->children))
  {
       next = list_next(e);
       cp = list_entry(e, struct child_process, elem);
       list_remove(&cp->elem);
       free(cp);
       e = next;
   }
}

//creates child process stuct and adds it to current threads child list
// For load, 0 = not loaded, - 1 = fail to load, 1 = loaded 
struct child_process* child_proc (int pid)
{
  struct child_process* cp = malloc(sizeof(struct child_process));
  cp->pid = pid;
  cp->load = 0;
  cp->wait = false;
  cp->exit = false;
  lock_init(&cp->wait_lock);
  list_push_back(&thread_current()->children, &cp->elem);
  return cp;
}


int user_to_kernel_ptr(const void *vaddr)
{
  // TO DO: Need to check if all bytes within range are correct
  // for strings + buffers
  check_pointer(vaddr);
  void *ptr =  (void *) pagedir_get_page(thread_current()->pagedir, vaddr);
  if (!ptr)
    {
      exit(-1);
    }
  return (int) ptr;
}
